using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using ESA.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<DataContext>(
    Options=>{
        var config=builder.Configuration; 
        var conString=config.GetConnectionString("Database");
        Options.UseSqlite(conString);
        Options.EnableSensitiveDataLogging();
        });

var app = builder.Build();




app.UseRouting();


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}");
app.MapControllerRoute(
    name: "product",
    pattern: "{controller=product}/{action=list}/{id?}");
app.MapControllerRoute(
    name: "Buyproduct",
    pattern: "{controller=product}/{action=BuyProduct}/{id?}");



app.Run();