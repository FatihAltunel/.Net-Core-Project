using ESA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ESA.Controllers{
    public class HomeController : Controller
{
    public IActionResult Index()
    {
            //  using(var db=new DataContext()){
            //      var products=db.Products;
            //      foreach(var p in products){
            //          db.Remove(p);
            //      }
            //      db.SaveChanges();
            //      db.Database.ExecuteSqlRaw("UPDATE sqlite_sequence SET seq = 0 WHERE name = 'Products';");
            //  }
          return View();
    }
    public IActionResult Login()
    {
        return View("Login");
    }
    [HttpPost]
    public IActionResult Login(User user)
    {
        using(var db=new DataContext()){
            var existingProduct = db.Users.FirstOrDefault(u => u.Email == user.Email);
            if(existingProduct==null){
            db.Add(user);
            db.SaveChanges();
            }
            else{
                
            }
        }
        return View();
    }
    public IActionResult Contacts()
    {
        return View("Contacts");
    }

    [HttpPost]
    public IActionResult Contacts(Comment comment)
    {
        using(var db=new DataContext()){
            var existingUser=db.Users.FirstOrDefault(u=>u.Email==comment.Email && u.Username==comment.Username);
            if(existingUser!=null){

                comment.User = existingUser;
                db.Add(comment);
                db.SaveChanges();
            }
            else{}
        }
        return View();
    }
}
}