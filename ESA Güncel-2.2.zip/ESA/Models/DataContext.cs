using Microsoft.EntityFrameworkCore;

namespace ESA.Models{
    public class DataContext:DbContext{
        public DataContext(DbContextOptions<DataContext>options):base(options){
            
        }

        public DataContext()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=Database.db");
            optionsBuilder.EnableSensitiveDataLogging();
        }
        public DbSet<Product>Products{get;set;} 
        public DbSet<User>Users{get;set;} 
        public DbSet<Comment>Comments{get;set;} 
    }
}